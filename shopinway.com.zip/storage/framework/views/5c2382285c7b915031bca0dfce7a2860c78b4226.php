<?php $__env->startSection('content'); ?>
<div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-heading border bottom">
                                        <h4 class="card-title">List of Discount Categories</h4>
                                        <div class="col text-right"><a class="btn btn-success" href="<?php echo e(url('admin/add-discount')); ?>">Add New Discount</a></div>
                                    </div>
                                    <div class="card-block">
                                    <div class="table-overflow">
                                            <table id="tablediscountlist" class="table table-lg table-hover">
                                                <thead>
                                                        <th>Discount Percent</th>
                                                        <th>Plan</th>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>