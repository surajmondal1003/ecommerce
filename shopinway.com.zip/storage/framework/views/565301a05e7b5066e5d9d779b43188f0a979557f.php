<?php $__env->startSection('content'); ?>


<div class="inner-page ct">
        <div class="container-fluid">
          <div class="row">
            <form action="<?php echo e(url('product-search')); ?>" method="POST" id="productSearchForm">
              <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
                  <div class="hi-icon-wrap hi-icon-effect wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="600ms">
                      <div class="rtbox-btm">
                          <section id="content">
                              <h2 class="up">Categories</h2>
                            <div id="accordion" class="accordion-container">
                                    
                                    <?php echo $accordionContent; ?>

                         
      
                                
                        
                            </div>
                            <!--/#accordion-->
                        
                        </section>
                        <!--/#content-->

                        <?php if($result): ?>
                        <div class="ckbox">
                            <h2 class="up">Price Range</h2>
                            
                              <input type="hidden" name="offset" value="<?php echo e($offset); ?>">
                                <?php if(!empty($search_term)): ?>
                                <input type="hidden" name="search_term" value="<?php echo e($search_term); ?>">
                                <?php else: ?>

                                <input type="hidden" name="search_term_category" value="<?php echo e($result[0]->category_url); ?>">
                              
                                <?php endif; ?>
                                <input type="hidden" id="total_count" value="<?php echo e($total_count); ?>">
                              <?php echo csrf_field(); ?>
                                <div class="checkbox range">
                                    <input id="price_range1"  name="price_range[0]" type="checkbox" value="1,200"
                                    <?php if(in_array('0',$priceChckbox)): ?>
                                    checked
                                    <?php endif; ?>
                                    />
                                    <label for="price_range1">1-200</label><br>
                                    <input id="price_range2"  name="price_range[1]" type="checkbox" value="200,500"
                                    <?php if(in_array('1',$priceChckbox)): ?>
                                    checked
                                    <?php endif; ?>
                                    />
                                    <label for="price_range2">200-500</label><br>
                                    <input id="price_range3"  name="price_range[2]" type="checkbox" value="500,1000"
                                    <?php if(in_array('2',$priceChckbox)): ?>
                                    checked
                                    <?php endif; ?>
                                    />
                                    <label for="price_range3">500-1000</label><br>
                                    <input id="price_range4"  name="price_range[3]" type="checkbox" value="1000,1500"
                                    <?php if(in_array('3',$priceChckbox)): ?>
                                    checked
                                    <?php endif; ?>
                                    />
                                    <label for="price_range4">1000-1500</label><br>
                                    <input id="price_range5"  name="price_range[4]" type="checkbox" value="1500,9999"
                                    <?php if(in_array('4',$priceChckbox)): ?>
                                    checked
                                    <?php endif; ?>
                                    />
                                    <label for="price_range5">1500 & Above</label><br>
                                </div>
                                <button type="submit" class="buybtn">APPLY</button>
                              
                           
                                
                        </div>
                        
                        <?php endif; ?>
                        </div>
                        
      
              
                  
                </div>
                </div>
            <div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
              <div class="lt-box">
                <div class="row">
                    <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                  
                  <?php if(!empty($search_term)): ?>
                  <p class="list-number-generate"><b>Showing <span id="listcount"><?php echo e($count); ?></span> results  for "<?php echo e($search_term); ?>"</b></p>
                  <?php endif; ?>

                  <?php if(!empty($search_term_category)): ?>
                  <p class="list-number-generate"><b>Showing <span id="listcount"><?php echo e($count); ?></span> results  for "<?php echo e($search_term_category); ?>"</b></p>
                  <?php endif; ?>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                    <select name="sortType" class="form-control rng-lw" onchange="this.form.submit()">
                      <option value="0">Relevance</option>
                      <option value="ASC" <?php if($sortType=='ASC'): ?> selected <?php endif; ?>>Low to High</option>
                      <option value="DESC" <?php if($sortType=='DESC'): ?> selected <?php endif; ?>>High to Low</option>
                    </select>
                    </div>
                  
                   
                  <div id="productListDiv">
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                    <div class="col-md-3 col-sm-6 col-xs-6 for-padding-less">
                            <div class="hi-icon-wrap hi-icon-effect wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="200ms">
                            <div class="big-box">
                              <div class="img-sec">
                                <a href="<?php echo e(url($row->category_url.'/'.$row->product_url)); ?>" target="_blank"><img src="<?php echo e(asset($row->image_name)); ?>" ></a>
                              </div>
                              <div class="txt-sec">
                                <div class="box">
                                  <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <a href="<?php echo e(url($row->category_url.'/'.$row->product_url)); ?>" target="_blank"><h4><?php echo e(str_limit($row->product_name,50)); ?></h4>
                                    </a>
                                    </div>
                                  
                                      <div class="icon hrt">
                                        <a href="javascript:void(0)" onclick="addToWishlist('<?php echo e($row->product_url); ?>')">
                                        <span><i class="fa fa-heart" aria-hidden="true"></i></span>
                                        </a>
                                      </div>
                                  
                                  </div>
                                  
                                  <div class="prc"><h3 class="lft-price"><strike>Rs <?php echo e(number_format($row->regular_price)); ?></strike></h3><h3 class="rgt-price">Rs <?php echo e(number_format($row->discount_price)); ?></h3></div>
                                
                                  <?php if($row->is_supreme=='1'): ?>
                                  <div class="supreme">
                                    <img src="<?php echo e(asset('assets/images/sup.png')); ?>" alt="">
                                  </div>
                                  <?php endif; ?>
                                 
                                </div>
                              </div>
                            </div>
                          </div>
                          </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                 
                </div>
              </div>
              
            </div>
           
            </form>
            
        </div>
      </div>
      <?php if($count != $total_count): ?>
      <div class="col-md-12">
              <a href="javascript:void(0)" class="buybtn loadMore" id="loadMoreBtn">SHOW MORE</a>
            </div>
      </div>
      <?php endif; ?>
      
      
      
      <?php $__env->stopSection(); ?>

      <?php $__env->startSection('scriptarea'); ?>
      <script>

        $('.loader4').hide();

                $(function() {
          var Accordion = function(el, multiple) {
              this.el = el || {};
              this.multiple = multiple || false;

              var links = this.el.find('.article-title');
              links.on('click', {
                  el: this.el,
                  multiple: this.multiple
              }, this.dropdown)
          }

          Accordion.prototype.dropdown = function(e) {
              var $el = e.data.el;
              $this = $(this),
                  $next = $this.next();

              $next.slideToggle();
              $this.parent().toggleClass('open');

              if (!e.data.multiple) {
                  $el.find('.accordion-content').not($next).slideUp().parent().removeClass('open');
              };
          }
          var accordion = new Accordion($('.accordion-container'), false);
        });


          $('#loadMoreBtn').click(function() {
           
                $('.loading').show();

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    var url = baseUrl + '/load-more-products';

                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: $('#productSearchForm').serialize(),
                        dataType: "json",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (response) {
                            if (response.status === true) {
                                $('.loading').hide();
                                $('#productListDiv').append(response.productDiv);

                                
                                $('input[name="offset"]').val(response.offset);
                                
                                $('#listcount').html(response.count+parseInt($('#listcount').html().toString()));

                                if(parseInt($('#listcount').html().toString()) == $('#total_count').val()){
                                  $('#loadMoreBtn').remove();
                                }
                               


                            }
                        }, error: function (xhr, error) {

                        }
                    });
              
          });


        
        </script>
      <?php $__env->stopSection(); ?>

      
<?php echo $__env->make('layouts.prodlistlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>