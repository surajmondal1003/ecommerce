<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta name="x-apple-disable-message-reformatting">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="telephone=no" name="format-detection">
    <title></title>
    <style>
    /* CONFIG STYLES Please do not delete and edit CSS styles below */


/* IMPORTANT THIS STYLES MUST BE ON FINAL EMAIL */



/* END RESPONSIVE STYLES */
    </style>
</head>

<body>
    <div class="es-wrapper-color">
        <!--[if gte mso 9]>
			<v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
				<v:fill type="tile" color="#efefef"></v:fill>
			</v:background>
		<![endif]-->
        <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0" bgcolor="#f2f2f2">
            <tbody>
                <tr>
                    <td class="esd-email-paddings" valign="top">
                        <table class="es-header" cellspacing="0" cellpadding="0" align="center">
                            <tbody style=" background:#000 !important;">
                                <tr>
                                    <td class="esd-stripe" esd-custom-block-id="1735" align="center">
                                        <table class="es-header-body" width="600" cellspacing="0" cellpadding="0"  bgcolor="#2d2d2c" align="center">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p5t es-p5b es-p15r es-p15l" align="left">
                                                        <!--[if mso]><table width="570" cellpadding="0" cellspacing="0"><tr><td width="180" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="center" width="100%" float="none">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p0r esd-container-frame" width="180" valign="top" align="center">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-image es-m-p0l es-m-txt-c" align="center" >
                                                                                        <a href="<?php echo e(url('')); ?>" target="_blank"><img src="<?php echo e(asset('assets/images/logo-ml.png')); ?>"  width="118"></a>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="es-content" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" esd-custom-block-id="1754" align="center">
                                        <table class="es-content-body" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="padding: 0 0 30px 0">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p10t es-p10b es-p20r es-p20l" esd-general-paddings-checked="false" align="left">
                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="560" valign="top" align="center">
                                                                        <table style="border-radius: 0px; border-collapse: separate;" width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p10t es-p15b" align="center" style=" font-size: 15px; line-height: 17px; padding: 10px 0 0 0;">
                                                                                        <h1 style="font-family: 'Raleway', sans-serif; font-weight: 300;">Thanks for your order<br></h1>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p5t es-p5b es-p40r es-p40l" align="center">
                                                                                        <p style="color: rgb(51, 51, 51); padding:0 80px;font-family: 'Raleway', sans-serif; font-weight: 300; margin: 0; ">You'll receive an email when your Order status is updated. If you have any questions, Call us (033) 2548 9016.<br></p>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-button es-p15t es-p10b" align="center">
                                                                                        <h2 style="font-family: 'Raleway', sans-serif; font-weight: 300; margin: 0; padding: 20px 0 0 0;">Order <?php echo e(strtoupper($data['status'])); ?></h2>
                                                                                     </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="es-content" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" esd-custom-block-id="1755" align="center">
                                        <table class="es-content-body" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="padding: 20px;">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p30b es-p20r es-p20l" align="left">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="280" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left" style=" float: left;">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p20b esd-container-frame" width="280" align="left">
                                                                        <table style="background-color: rgb(254, 249, 239); border-color: rgb(239, 239, 239); border-collapse: separate; border-width: 1px 0px 1px 1px; border-style: solid; height:200px; overflow:hidden;" width="100%" cellspacing="0" cellpadding="0" bgcolor="#fef9ef">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20t es-p10b es-p20r es-p20l" align="left" style=" padding: 20px 20px 10px 20px; margin: 0;">
                                                                                        <h4 style=" margin: 0; font-family: 'Raleway', sans-serif; font-weight: 6font-family: 'Raleway', sans-serif; font-weight: 600;">SUMMARY:</h4>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20b es-p20r es-p20l" align="left" style=" padding: 0 20px 20px 20px; margin: 0;">
                                                                                        <table style="width: 100%;" class="cke_show_border" cellspacing="1" cellpadding="1" border="0" align="left">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;">Order ID:</span></td>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;"><?php echo e($data['order_no']); ?></span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;">Invoice No:</span></td>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;"><?php echo e($data['invoice_no']); ?></span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;">Order Date:</span></td>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;"><?php echo e($data['created_at']); ?></span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;">Order Net Total:</span></td>
                                                                                                    <td><span style="font-size: 14px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;"><?php echo e($data['net_total']); ?></span></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                        <p style="line-height: 150%;"><br></p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="0"></td><td width="280" valign="top"><![endif]-->
                                                        <table class="es-right" cellspacing="0" cellpadding="0" align="right" style=" float: left;">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="280" align="left">
                                                                        <table style="background-color: rgb(254, 249, 239); border-collapse: separate; border-width: 1px; border-style: solid; border-color: rgb(239, 239, 239); height:200px; overflow:hidden;" width="100%" cellspacing="0" cellpadding="0" bgcolor="#fef9ef">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20t es-p10b es-p20r es-p20l" align="left"  style=" padding: 20px 20px 10px 20px; margin: 0;">
                                                                                        <h4 style=" margin: 0;font-family: 'Raleway', sans-serif; font-weight: 600;">SHIPPING ADDRESS:<br></h4>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20b es-p20r es-p20l" align="left" style=" padding: 0 20px 21px 20px; margin: 0;">
                                                                                        <p style=" margin: 0; padding: 3px 0; font-family: 'Raleway', sans-serif; font-weight: 300;"><?php echo e($data['address']); ?>,<?php echo e($data['landmark']); ?>,<?php echo e($data['pincode']); ?>,<?php echo e($data['city']); ?></p>
                                                                                   
                                                                                        <p style=" margin: 0; padding: 3px 0; font-family: 'Raleway', sans-serif; font-weight: 300;">Mobile : <?php echo e($data['phone_no']); ?></p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="es-content" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" esd-custom-block-id="1758" align="center" >
                                        <table class="es-content-body" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p10t es-p10b es-p20r es-p20l" esd-general-paddings-checked="false" align="left" style=" padding: 10px 20px;">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="270" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p0r es-m-p20b esd-container-frame" width="270" valign="top" align="center">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20l" align="left">
                                                                                        <h4 style=" margin:0; font-family: 'Raleway', sans-serif; font-weight: 300;">ITEMS ORDERED</h4>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="20"></td><td width="270" valign="top"><![endif]-->
                                                        <table cellspacing="0" cellpadding="0" align="right">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="270" align="left">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text" align="left">
                                                                                        <table style="width: 100%;" class="cke_show_border" cellspacing="1" cellpadding="1" border="0">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td><span style="font-size:13px;font-family: 'Raleway', sans-serif; font-weight: 300;">NAME</span></td>
                                                                                                    <td style="text-align: center;" width="60"><span style="font-size:13px;"><span style="line-height: 100%;font-family: 'Raleway', sans-serif; font-weight: 300;">QTY</span></span>
                                                                                                    </td>
                                                                                                    <td style="text-align: center;" width="100"><span style="font-size:13px;"><span style="line-height: 100%;font-family: 'Raleway', sans-serif; font-weight: 300;">PRICE</span></span>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="esd-structure es-p20r es-p20l" esd-general-paddings-checked="false" align="left" style=" padding: 0 20px 15px 20px;">
                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="560" valign="top" align="center">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-spacer es-p10b" align="center">
                                                                                        <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style="border-bottom: 1px solid rgb(239, 239, 239); background: rgba(0, 0, 0, 0) none repeat scroll 0% 0%; height: 1px; width: 100%; margin: 0px;"></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>

                                                <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="esd-structure es-p5t es-p10b es-p20r es-p20l" esd-general-paddings-checked="false" align="left">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="178" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p0r es-m-p20b esd-container-frame" width="178" valign="top" align="center">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-image" align="center">
                                                                                    <a href="" target="_blank"><img src="<?php echo e(asset($product_item['image_name'])); ?>"  class="adapt-img"  width="125"></a>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="20"></td><td width="362" valign="top"><![endif]-->
                                                        <table cellspacing="0" cellpadding="0" align="right">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="362" align="left">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text" align="left">
                                                                                        <p><br></p>
                                                                                        <table style="width: 100%;" class="cke_show_border" cellspacing="1" cellpadding="1" border="0">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style=" font-size: 15px; line-height: 18px; font-weight: 600;font-family: 'Raleway', sans-serif;"><?php echo e(str_limit($product_item['product_name'],35)); ?></td>
                                                                                                <td style="text-align: center; font-family: 'Raleway', sans-serif; font-weight: 300;" width="60"><?php echo e($product_item['qty']); ?></td>
                                                                                                    <td style="text-align: center; font-family: 'Raleway', sans-serif; font-weight: 300;" width="100">Rs. <?php echo e($product_item['subtotal']); ?></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                        <p><br></p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>
                                               
                                                <tr>
                                                    <td class="esd-structure es-p20r es-p20l" esd-general-paddings-checked="false" align="left"style=" padding: 0 20px 15px 20px;">
                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="560" valign="top" align="center">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-spacer es-p10b" align="center">
                                                                                        <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style="border-bottom: 1px solid rgb(239, 239, 239); background: rgba(0, 0, 0, 0) none repeat scroll 0% 0%; height: 1px; width: 100%; margin: 0px;"></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                                                <tr>
                                                    <td class="esd-structure es-p5t es-p30b es-p40r es-p20l" align="left" style="padding: 0 20px">
                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="540" valign="top" align="center">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text" align="right">
                                                                                        <table style="width: 500px;" class="cke_show_border" cellspacing="1" cellpadding="1" border="0" align="right">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style="text-align: right; font-size: 18px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;">Subtotal</td>
                                                                                                <td style="text-align: right; font-size: 18px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;">Rs. <?php echo e($data['itemtotal']); ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td style="text-align: right; font-size: 18px; line-height: 150%; font-family: 'Raleway', sans-serif; font-weight: 300;">Delivery Charge:</td>
                                                                                                <td style="text-align: right; font-size: 18px; line-height: 150%; color: #d48344; font-family: 'Raleway', sans-serif; font-weight: 300;"><strong>Rs. <?php echo e($data['delivery_charge']); ?></strong></td>
                                                                                                </tr>
                                                                                                
                                                                                                <tr>
                                                                                                    <td style="text-align: right; font-size: 18px; line-height: 150%; padding: 0 0 20px 0; font-family: 'Raleway', sans-serif; font-weight: 300;"><strong>Order Total:</strong></td>
                                                                                                <td style="text-align: right; font-size: 18px; line-height: 150%; color: #d48344; font-family: 'Raleway', sans-serif; font-weight: 300;"><strong>Rs.<?php echo e($data['net_total']); ?></strong></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                        <p style="line-height: 150%;"><br></p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="es-header" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" esd-custom-block-id="1735" align="center">
                                        <table class="es-header-body" width="600" cellspacing="0" cellpadding="0"  bgcolor="#d9d9d9" align="center">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p5t es-p5b es-p15r es-p15l" align="left">
                                                        <!--[if mso]><table width="570" cellpadding="0" cellspacing="0"><tr><td width="180" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p0r esd-container-frame" width="180" valign="top" align="left">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-image es-m-p0l es-m-txt-c" align="center" >
                                                                                    <a href="<?php echo e(url('')); ?>" target="_blank"><img src="<?php echo e(asset('assets/images/logo-ml.png')); ?>"  width="118"></a>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>