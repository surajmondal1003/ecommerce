<?php $__env->startSection('content'); ?>
<div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-heading border bottom">
                                        <h4 class="card-title">Edit Page Meta : <?php echo e($pagemeta['pName']); ?></h4>
                                    </div>
                                    <div class="card-block">
                                        <div class="mrg-top-40">
                                            <div class="row">
                                                <div class="col-md-10 ml-auto mr-auto">
                                                    <form id="updatePageMetaForm">
                                                    <input type="hidden" name="id" value="<?php echo e($pagemeta['pId']); ?>">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label>Page Title</label>
                                                                    <input type="text" name="inputTitle" placeholder="Page Title" class="form-control cForm" value="<?php echo e($pagemeta['pTitle']); ?>">
                                                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label>Meta Description</label>
                                                                    <input type="text" name="inputMetaDesc" placeholder="Meta Description" class="form-control cForm" value="<?php echo e($pagemeta['mDesc']); ?>">
                                                                   
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label>Meta Keyword</label>
                                                                    <input type="text" name="inputMetaKeyWord" id="inputMetaKeyWord" class="form-control" placeholder="comma separated keyword" value="<?php echo e($pagemeta['mKeyWord']); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label>Meta Robot</label>
                                                                   <input type="text" name="inputMetaRobot" class="form-control" placeholder="Meta robot" value="<?php echo e($pagemeta['mRobot']); ?>">
                                                                </div>
                                                            </div>
                                                       
                                                        
                                                        <div class="col-md-4 col-xs-4">
                                                            <div class="form-group">
                                                                    <label>Canonical Link</label>
                                                                    <input type="text" name="inputCanonicalLink" class="form-control cForm" placeholder="Canonical Link" value="<?php echo e($pagemeta['cLink']); ?>">
                                                                    
                                                                </div>
                                                            </div>
                                                        <div class="col-md-4 col-xs-4">
                                                        <div class="form-group">
                                                                    <label>Revisit after</label>
                                                                    <input type="text" name="inputRevisitAfter" class="form-control cForm" placeholder="Meta  revisit after" value="<?php echo e($pagemeta['mRevisitAfter']); ?>">
                                                                    
                                                                </div>
                                                                </div>
                                                       </div>
                                                       <div class="row">
                                                        <div class="col-md-4 col-xs-4">
                                                        <!-- <div class="form-group">
                                                                    <label>Canonical Link</label>
                                                                    <input type="text" name="inputCanonicalLink" class="form-control cForm" placeholder="Canonical Link">
                                                                    
                                                                </div> -->
                                                        </div>
                                                        <div class="col-md-4 col-xs-4">
                                                        <div class="form-group">
                                                                    <label>OG Locale</label>
                                                                    <input type="text" name="inputOglocale" class="form-control cForm" placeholder="Og Locale"  value="<?php echo e($pagemeta['oLocal']); ?>">
                                                                    
                                                                </div>
                                                        </div>
                                                        <div class="col-md-4 col-xs-4">
                                                        <div class="form-group">
                                                                    <label>OG Type</label>
                                                                    <input type="text" name="inputOgType" class="form-control cForm" placeholder="Og Type" value="<?php echo e($pagemeta['oType']); ?>">
                                                                    
                                                                </div>
                                                        </div>
                                                       </div>
                                                       <div class="row">
                                                        <div class="col-md-4 col-xs-4">
                                                            <div class="form-group">
                                                            <label>OG Image</label>
                                                                    <input type="text" name="inputOgImage" class="form-control cForm" placeholder="Og Image" value="<?php echo e($pagemeta['oImage']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 col-xs-4">
                                                            <div class="form-group">
                                                            <label>OG Title</label>
                                                                    <input type="text" name="inputOgTitle" class="form-control cForm" placeholder="Og Title" value="<?php echo e($pagemeta['oTitle']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 col-xs-4">
                                                            <div class="form-group">
                                                            <label>OG Description</label>
                                                                    <input type="text" name="inputOgDescription" class="form-control cForm" placeholder="Og Description" value="<?php echo e($pagemeta['oDesc']); ?>">
                                                            </div>
                                                        </div>
                                                       </div>
                                                       <div class="row">
                                                        <div class="col-md-4 col-xs-4">
                                                        <div class="form-group">
                                                            <label>OG Url</label>
                                                                    <input type="text" name="inputOgUrl" class="form-control cForm" placeholder="Og Url" value="<?php echo e($pagemeta['oUrl']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 col-xs-4">
                                                        <div class="form-group">
                                                            <label>OG Site Name</label>
                                                                    <input type="text" name="inputOgSiteName" class="form-control cForm" placeholder="Og Site Name" value="<?php echo e($pagemeta['oSite']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 col-xs-4">
                                                        <div class="form-group">
                                                            <label>Extra Head</label>
                                                                    <input type="text" name="inputExtraHeadCode" class="form-control cForm" placeholder="Extra head means site verification code etc" value="<?php echo e($pagemeta['eHeadCode']); ?>">
                                                            </div>
                                                        </div>
                                                       </div>
                                                        <div class="row">
                                                            <div class="col-md-6 col-xs-6">
                                                            
                                                            </div>
                                                            <div class="col-md-6 col-xs-6">
                                                                <div class="text-right mrg-top-5">
                                                                    <button type="submit" class="btn btn-success" id="metaUpdate">Save</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>