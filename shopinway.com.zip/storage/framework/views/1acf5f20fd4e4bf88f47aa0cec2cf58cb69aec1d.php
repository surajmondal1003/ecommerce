<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
                                <form id="updateContentForm" method="post" action="<?php echo e(action('AdminPageController@updateContent')); ?>">
                                    <input type="hidden" name="id" value="<?php echo e($content->id); ?>">
                                    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                                <div class="card">
                                    <div class="card-heading border bottom">
                                        <h4 class="card-title">Update Content : <?php echo e($content->page_name); ?></h4>
                                    </div>
                                    <div class="card-block">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                    <label>Page Content</label>
                                                    <textarea name="pageeditor" id="pageeditor" class="form-control"><?php echo $content->page_content; ?></textarea>
                                                <span class="form-error"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                                                <div class="text-right mrg-top-5">
                                                                    <button type="submit" class="btn btn-success" id="updatePageContent">Save</button>
                                                                </div>
                                                            </div>
                                    </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scriptarea'); ?>
<!-- <script>
    function test(){
        var data = document.getElementById('pageeditor').innerHTML;   
        
    }
    window.load=test();
</script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>