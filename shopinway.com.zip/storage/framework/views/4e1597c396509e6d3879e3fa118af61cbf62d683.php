<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="description" content="">
<meta name="author" content="">
<title>IP LAWS</title>
<!-- Bootstrap Core CSS -->
<style type="text/css">
  td{ padding: 4px 0 4px 15px; }
</style>
</head>
<body style="background: #d5d5d6; padding: 100px 0 ">


  <table style=" width: 696px; margin: 0 auto; background: #ffecd2; text-align: center; ">
    <tr style=" text-align: center;">
    <td><img src="images/logo.png" alt=""  style=" padding: 10px 0;"></td>
    </tr>
  </table>
  <table style="width: 700px; margin: 0 auto"> 
      <tr>  
          <td style=" padding: 30px; background: #fff; margin: 0;  margin: 0 auto;">
  <table class="text" style="width: 600px;; margin: 0 auto;">

    <h2 style=" width: 585px; margin: 0 auto; padding: 15px 0 15px 15px; font-size: 16px; line-height: 18px; font-weight: 300; background: #fff;">20.09.18</h2>



    <table class="tbl">
       
      <table style="border:1px solid #54b1ff; border-top: none; width: 600px; margin: 0 auto; background: #fff; padding: 30px; ">
  <thead>
    <h2 style=" text-align: center; margin: 0 auto; padding: 4px 0; background: #e7f4ff; border:1px solid #54b1ff; font-size: 18px; line-height: 22px; text-transform: uppercase; font-weight: 400; width: 598px;">Contact Information</h2>
  </thead>
  <tbody>
    <tr>
      <td style=" width: 120px;">Name</td>
      <td><?php echo e($inputName); ?></td>
    </tr>
    <tr>
      <td style=" width: 120px;">Email</td>
      <td><?php echo e($sender_email); ?></td>
    </tr>
  </tbody>
  <tfoot>
    <tr>
      <td style=" width: 120px;">Contact No.</td>
      <td><?php echo e($inputPhone); ?></td>
    </tr>
    
  </tfoot>
</table>
    </table>
  </table>
 </td>
      </tr>
   </table>



</body>
</html>
