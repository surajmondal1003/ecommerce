
<?php $__env->startSection('content'); ?>
<div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <form id="stockForm">
                                    <div class="card-block">
                                    <div class="table-overflow">
                                            <table id="tablestocklist" class="table table-lg table-hover">
                                                <thead>
                                                        
                                                        <th>Check Item</th>
                                                        <th>Name</th>
                                                        <th>SKU</th>
                                                        <th>Description</th>
                                                        <th>Regular Price</th>
                                                        <th>Discount Price</th>
                                                        <th>Exisiting Quantity</th>
                                                        <th>New Quantity</th>
                                                       
                                                 
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                    </div>
                                    <div id="error">
                                    </div>
                        
                                    <div class="row">
                                            <div class="col-md-6 col-xs-6">
                                                <div class="text-right mrg-top-5">
                                                    <button type="submit" class="btn btn-success" id="stockSubmit">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptarea'); ?>

<script>
    // $('.itemcheck').on('click',function(){
    //     alert();
    //     $('#error').html('');
    // });
        
    $(document.body).on('change','.itemcheck',function(){
    
    if(this.checked){
      
        $('#error').html('');
    }
   
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>