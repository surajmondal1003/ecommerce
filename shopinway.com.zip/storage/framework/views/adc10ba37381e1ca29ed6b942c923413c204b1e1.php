<?php $__env->startSection('content'); ?>
<div class="vision1">
    <div class="container">
        <div class="col-md-12 col-xs-12 ">
          <div class="lt-section" style="padding-top: 60px;">
            <h3></h3>
            <h2>404</h2>
            <p>page not found</p>
            <a href="<?php echo e(url('/')); ?>" class="btn-default2">Back to Home</a>
          </div>
        </div>
        <div class="clearfix"></div>
      </div> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>