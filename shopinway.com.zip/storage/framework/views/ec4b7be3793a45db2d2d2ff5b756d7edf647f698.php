<?php $__env->startSection('content'); ?>

<div class="inner-page-hd-member">


        <div class="full-card">
          <div class="container">
          <h2 class="member-sub"> Shopinway Student Membership Options:</h2>
          <div class="row">
            <div class="col-md-12 col-sm-6 col-xs-12">
              <div class="box">
                <div class="row">

                <?php $__currentLoopData = $membership; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    
                        <div class="card-inr">
                        <h2 class="card-heading"><?php echo e($item['membership_name']); ?></h2>
                        <div class="prime-price">
                                  <table>
                                    <tr>
                                      <th>TENURE </th>
                                     
                                      <th>Price</th>
                                    </tr>
                                    
                                    <?php $__currentLoopData = $item['detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($detailitem->membership_plan); ?></td>
                                      
                                    <td class="bg">Rs <?php echo e($detailitem->membership_price); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
          
                                  </table>
                                </div>
                                 <div class="prime-desc">
                                 <p><?php echo e($item['description']); ?></p>
                                </div>
                                
                              <a href="javascript:void(0)" class="crda" onclick="load_membershipForm('<?php echo e($item['membership_cat_code']); ?>')">Join Now</a>
                              
                              </div>
                  
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>
              </div>
            </div>
            
          </div>
          <div class="clearfix"></div>
        </div>
        </div>


        <div class="main">
      <div class="container">
       <!--  <h1 class="member-head">Student Membership</h1> -->
        <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="lt-sec">
          
          <h2 class="member-sub">FREQUENTLY ASKED QUESTIONS</h2>
          <h3 class="member-sub2">What is <a href="#">Shopinway Student Membership?</a></h3>
          <p>Shopinway.com has Student Members all over the West Bengal based Engineering & Management colleges. </p>
          <p><strong>Shopinway Student Membership Enrollment:</strong> FREE fast Shipping, FREE MAKAUT Organizer , MATRIX Polytechnic Organizer and will soon be able to get benefits on upcoming products belongs to Only for Shopinway Student members. <span> Join Shopinway Student Membership Membership till January 31, 2019. </span></p>
          </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
             <div class="rt-sec">
               <img src="<?php echo e(asset('assets/images/banner1.jpg')); ?>" alt="">
             </div>
          </div>
        </div>
        </div>
        
        </div>


        <div class="btm-sec-member">
        <div class="container">

          <div class="valid">
            <h3 class="vd">   How long Shopinway <a href="#">  MATRIX Annual membership</a> is valid for?</h3>
            <p>Shopinway MATRIX Annual Membership is valid for Engineering  college students and for the (2) two semester from the date of the registration of the Student Membership.</p>
          </div>
          <div class="valid">
            <h3 class="vd">    How long Shopinway <a href="#"> MATRIX Prime membership</a> is valid for?</h3>
            <p>Shopinway MATRIX Prime Membership is valid for Engineering  college students and till the FINAL semester from the date of the registration of the Student Membership.</p>
          </div>
          <div class="valid">
            <h3 class="vd">  How long Shopinway<a href="#"> MAKAUT Annual membership </a> is valid for?</h3>
            <p>Shopinway MAKAUT Annual Membership is valid for Engineering & Management college students and for the (2) two semester from the date of the registration of the Student Membership.</p>
          </div>
          <div class="valid">
            <h3 class="vd"> How long Shopinway<a href="#"> MAKAUT Prime membership</a> is valid for?</h3>
            <p>Shopinway Student Prime Membership is valid for Engineering & Management college students and till the final semester from the date of the registration of the Student Membership.</p>
          </div>


          <div class="valid-mdl">
           <h2 class="member-sub">How do I register for Shopinway Student membership?</h2>
           <ul>
             <li><span> MATRIX Annual Membership:</span> You can register to the service, <a href="#">"Click here"</a> or <a href="#">contact</a> to Shopinway Student Member Head from your college, where you will be prompted for your membership application and payment details.</li>
             <li><span>MATRIX Prime Membership:</span> You can register to the service, <a href="#">"Click here"</a> or <a href="#">contact</a> to Shopinway Student Member Head from your college, where you will be prompted for your membership application and payment details.</li>
             <li><span> MAKAUT Annual Membership:</span> You can register to the service, <a href="#">"Click here"</a> or <a href="#">contact</a> to Shopinway Student Member Head from your college, where you will be prompted for your membership application and payment details.</li>
             <li><span>MAKAUT rime Membership:</span> You can register to the service, <a href="#">"Click here"</a> or <a href="#">contact</a> to Shopinway Student Member Head from your college, where you will be prompted for your membership application and payment details.</li>
           </ul>
          </div>
          <div class="valid-mdl">
           <h2 class="member-sub">Can I utilise Membership benefits for purchases across all products?     </h2>
           <ul>
             <li>Currently, exclusive benefits and priority services are applicable only on MAKAUT Organizer & MATRIX Polytechnic Organizer products.</li>
           </ul>
          </div>
          <div class="valid-mdl">
           <h2 class="member-sub"> May I use different addresses to get my products?</h2>
           <ul>
             <li>Yes, you may continue to enjoy your Shopinway Student Membership benefits on orders delivered to other addresses. But not all benefits are available on all pincodes. So, we suggest you check with your locations pin-code. Members are advised to intimate their change of address to Shopinway HQ immediately, quoting their Membership Number, old address, complete new address with pin-code through an email at <a href="#">support@shopinway.com </a> . The contact no (tele as well as mobile) should also be given.</li>
           </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="ftr-sec-member">
            <div class="container">
              <h2 class="heading-tp">Terms & Conditions for Shopinway Student Membership </h2>
              <h2 class="member-sub"> Membership Service & Benefits:</h2>
              <ul>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Student Membership is our one-time paid membership for the students who wish to get access to exclusive benefits
                  and priority service for MAKAUT Organizer & MATRIX Polytechnic Organizer products.</li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>The student membership is non-transferable to any third person whatsoever.</li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Shopinway MATRIX Annual Student Members to the service get access to Free Two semesters MATRIX Polytechnic Organizer
                  with Free Delivery from the date of the registration of the Shopinway Student Membership.</li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Shopinway MATRIX Prime Student Members to the service get access to Free ALL semesters MATRIX Polytechnic Organizer
                  with Free Delivery from the date of the registration of the Shopinway Student Membership.
                </li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Shopinway MAKAUT Annual Student Members to the service get access to Free Two semesters MAKAUT Organizer with
                  Free Delivery from the date of the registration of the Shopinway Student Membership.</li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Shopinway MAKAUT Prime Student Members to the service get access to ALL semesters MAKAUT Organizer with Free
                  Delivery from the date of the registration of the Shopinway Student Membership.</li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Each Semester Members will get their Free shipment of MAKAUT Organizer & MATRIX Polytechnic they belongs to within
                  7 working days from the date of latest edition get launched.</li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Shipping of the respective product will be done at shipping address mentioned during enrollment.
                </li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>Student Membership Card must be shown by the student members when demanded.
                </li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span> As a Student Member, you are eligible for the benefit of Refer & Earn for a particular referral.</li>
                <li>
                  <span>
                    <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                  </span>The company is not entitled in making any chain hence the referral benefits will be given to the member with
                  that mentioned Reference ID in the membership application.</li>
              </ul>
      
              <h2 class="member-sub"> Membership Termination:</h2>
              <p>Shopinway Student Members are not permitted to purchase products for the purpose of resale. In case of any misuse
                of your membership, including but not limited to such resale of products, Shopinway shall be entitled to terminate
                your membership at any time without prior notice and with no obligation to refund money.</p>
      
              <h3 class="vd">If you still have any questions?
                <a href="#"> Contact Us</a>
              </h3>
            </div>
          </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>