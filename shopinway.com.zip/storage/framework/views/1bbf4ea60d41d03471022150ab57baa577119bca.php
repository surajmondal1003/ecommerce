
<?php $__env->startSection('content'); ?>
<?php displayBlogs();?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>