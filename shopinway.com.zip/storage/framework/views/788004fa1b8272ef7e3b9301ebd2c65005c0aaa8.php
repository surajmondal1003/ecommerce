<?php $__env->startSection('content'); ?>
<div class="banner">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
    
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
          <div class="item active">
            <div class="container">
            <div class="row">
              <div class="col-md-12 col-xs-12">
                <div class="text">
                    <h2>Innovation</h2>
                    <p>It creates a leader and followers</p>
                    <a class="btnon" href="#you">Get Started</a>
              </div>
              </div>
            </div>
          </div>
          </div>
    
          <div class="item">
              <div class="box"></div>
          <div class="container">
            <div class="row">
              <div class="col-md-12 col-xs-12">
                <div class="text">
                    <h2>Protection</h2>
                    <p>A step towards more profits</p>
                    <a class="btnon" href="#you">Get Started</a>
              </div>
              </div>
            </div>
          </div>
          </div>
        
          <div class="item">
              <div class="box"></div>
        <div class="container">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text">
                    <h2>Proliferation</h2>
                    <p>A lead for global expansion</p>
                    <a class="btnon" href="#you">Get Started</a>
              </div>
              </div>
            </div>
          </div>
          </div>
        </div>
    </div>
</div>
<div class="about">
 
    <div class="container">
            <h1>How Would You Know You’re A Genius If You Don’t Share Your Genius With Others.</h1>
        <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                        
                    <div class="ltsec">
                            <div data-aos="fade-up"
                                data-aos-duration="2400">
                        <p>You wouldn’t want to share your genius today, if tomorrow another will pretend it’s there’s. Welcome to IPLaws India – Your one stop to Innovation Protection. Powered by a dedicated team of professionals this website is aimed at giving anyone, anywhere in the world an understanding of Intellectual Property and its Rights [IPR’s] especially in India. Should you have any further questions or seek legal advice, please don't hesitate to contact us. Here at BiswajitSarkar we....</p>
                        </div>
                        <div class="box">
                            <div class="row">
                                    <div data-aos="fade-up"
                                    data-aos-duration="2400">
                                <div class="in-box">
                                    <div class=" col-lg-2 col-md-3 col-sm-3 col-xs-12">
                                        <div class="icon"></div>
                                    </div>
                                    <div class=" col-lg-10 col-md-9 col-sm-9 col-xs-12">
                                        <div class="txt">
                                            <h3>Guarantee Speed and Efficency In All Matters</h3>
                                            <p>The promise of excellence and professionalism is key to the firm. </p>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                </div>
                                <div data-aos="fade-up"
                                data-aos-duration="2400">
                                <div class="in-box">
                                    <div class=" col-lg-2 col-md-3 col-sm-3 col-xs-12">
                                        <div class="icon"></div>
                                    </div>
                                    <div class=" col-lg-10 col-md-9 col-sm-9 col-xs-12">
                                        <div class="txt">
                                            <h3>Are A Global Firm</h3>
                                            <p>So whether you’re from another country or from India itself, we can help!! </p>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                </div>
                                <div data-aos="fade-up"
                                data-aos-duration="2400">
                                <div class="in-box">
                                    <div class=" col-lg-2 col-md-3 col-sm-3 col-xs-12">
                                        <div class="icon"></div>
                                    </div>
                                    <div class=" col-lg-10 col-md-9 col-sm-9 col-xs-12">
                                        <div class="txt">
                                            <h3>We Are More Than Just Your Lawyers…</h3>
                                            <p>We are your friends; we will stick with you till the end.</p>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                        <div data-aos="fade-up"
                                data-aos-duration="2400">
                    <div class="img-box">
                        <img src="<?php echo e(asset('assets/images/iplawsindia_home_about.jpg')); ?>" alt="">
                    </div>
                    </div>
                </div>
        </div>
    </div>
</div>
<div id="you">
<div class="case">
    <div class="container">
        <h2  class="bdr"> You Can Get Ideas About</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.Lorem ipsum dolor sit amet,</p>
  <section id="demos">
      <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel owl-theme">
                <div data-aos=""
                data-aos-duration="600">
           
              <div class="item">
                  <div class="box">

                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN AGRICULTURE</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            
            </div>
            <div data-aos=""
                data-aos-duration="1200">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN HEALTH SECTOR </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            </div>
            <div data-aos=""
                data-aos-duration="1800">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>CYBER IP </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            </div>
            <div data-aos=""
                data-aos-duration="2400">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN BOLLYWOOD</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            </div>
            <div data-aos=""
                data-aos-duration="3000">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN HOSPITALITY</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            </div>
            <div data-aos=""
                data-aos-duration="600">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN FINANCIAL SECTOR</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            </div><div data-aos=""
            data-aos-duration="1200">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>ENVIRONMENTAL IP</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
        </div>
            </div>
            <div data-aos=""
                data-aos-duration="1800">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN THE AUTOMOBILE INDUSTRY</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
        </div>
            </div>
            <div data-aos=""
                data-aos-duration="2400">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN FASHION </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
        </div>
            </div>
            <div data-aos=""
                data-aos-duration="3000">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN THE ONLINE STREAMING INDUSTRY </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
        </div>
            </div>
            <div data-aos=""
                data-aos-duration="3600">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP IN THE 3D PRINTING FIELD</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            </div>
            <div data-aos=""
                data-aos-duration="3600">
              <div class="item">
                  <div class="box">
                <div class="img-box">
                    <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="">
                </div>
                <div class="text">
                    <h2>IP AROUND THE WORLD TODAY.</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu est felis.</p>
                </div>
            </div>
            </div>
            </div>
          </div>
      </div>
  </div>
</section>
    </div>
</div>
</div>
<div class="career">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 col-xs-12">
                    <div data-aos="fade-up"
                    data-aos-duration="1200">
                <div class="rt-form">
                    <div class="img-block">
                        <img src="<?php echo e(asset('assets/images/ipcarrear.jpg')); ?>" alt="">
                    </div>
                    <div class="txt">
                        <h2>Your Query For <span> IP FORUM</span></h2>
                        
                        <a href="<?php echo e(url('/ipforum')); ?>">Take Me There</a>
                    </div>
                </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                    <div data-aos="fade-up"
                    data-aos-duration="1800">
                <div class="rt-form new">
                    <h2><span>Notice</span></h2>
                    <div class="txt">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tellus ante, luctus in facilisis non, lobortis pharetra lacus. Proin eu semper lorem. Etiam vehicula mauris id purus semper mollis. Vivamus quis ante quis diam euismod molestie. Donec a augue in est pharetra efficitur non at diam. Aliquam in metus eget purus luctus feugiat. Vestibulum hendrerit eros ante, a cursus urna pellentesque in. </p></div>
                </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                    <div data-aos="fade-up"
                    data-aos-duration="2400">
                <div class="rt-form">
                    <div class="img-block">
                        <img src="<?php echo e(asset('assets/images/ipcarrear2.jpg')); ?>" alt="">
                    </div>
                    <div class="txt">
                        <h2>Student Enroll For <span>IP CAREER</span></h2>
                        <a href="<?php echo e(url('/career')); ?>">I am Interested</a>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="blog">
    <div class="container">
        <h2 class="bdr"> NOW AND THEN</h2>
        <p>Unless you try to find something new, you remain incomplete.</p>
        <section id="demos">
      <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel2 owl-theme">
          <?php displayFeaturedBlogs(); ?>
          </div>
      </div>
  </div>
</section>
    </div>
</div>
<div class="iconbox">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div data-aos="flip-left" data-aos-duration="800">
                <div class="box">
                    <div class="img-box">
                        <img src="<?php echo e(asset('assets/images/imgicon1.png')); ?>" alt="">
                    </div>
                    <div class="text">
                        <h2>IP Library</h2>
                        <p><a href="#">Important Cases </a></P>
                        <p><a href="#">Important Links </a></P>
                        <p><a href="#">Articles </a></P>
                        <p><a href="#">Downloads </a></p>
                    </div>
                </div>
            </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                    <div data-aos="flip-left" data-aos-duration="1200">
                <div class="box">
                    <div class="img-box">
                        <img src="<?php echo e(asset('assets/images/imgicon2.png')); ?>" alt="">
                    </div>
                    <div class="text">
                        <h2>IP Club</h2>
                        <p><a href="#">Hot Topics </a></P>
                        <p><a href="#">Events </a></P>
                        <p><a href="#">News </a></P>
                        <p><a href="#">Seminar </a></p>
                    </div>
                </div>
            </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                    <div data-aos="flip-left" data-aos-duration="1800">
                <div class="box">
                    <div class="img-box">
                        <img src="<?php echo e(asset('assets/images/imgicon3.png')); ?>" alt="">
                    </div>
                    <div class="text">
                        <h2>IP Office</h2>
                        <p><a href="#">Hot Topics </a></P>
                        <p><a href="#">Events </a></P>
                        <p><a href="#">News </a></P>
                        <p><a href="#">Seminar </a></p>
                    </div>
                </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                    <div data-aos="flip-left" data-aos-duration="2400">
                <div class="box">
                    <div class="img-box">
                        <img src="<?php echo e(asset('assets/images/imgicon4.png')); ?>" alt="">
                    </div>
                    <div class="text">
                        <h2>IP Network</h2>
                        <P><a href="#">Important Links </a></P>
                        <p><a href="#">International  </a></P>
                        <p><a href="#">Correspondent </a></P>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>