<?php $__env->startSection('content'); ?>
<div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-heading border bottom">
                                        <h4 class="card-title">Student membership Details</h4>
                                    </div>
                                    <div class="card-block">
                                        <div class="mrg-top-40">
                                            <div class="row">
                                                <div class="col-md-12 ml-auto mr-auto">
                                                    <form id="updatestudentmembershipForm">
                                                            <div class="row">

                                                                   
    
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label>Membership Unique No</label>
                                                                        <input type="text" readonly  placeholder="This will show in Front end" 
                                                                    class="form-control cForm" value="<?php echo e($membership['student_unique_no']); ?>">
                                                                        <span class="form-error"></span>
                                                                    </div>
                                                                </div>
                                                                
                                                                
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label>Student Name</label>
                                                                        <input type="text" readonly  placeholder="This will show in Front end" 
                                                                        class="form-control cForm"  value="<?php echo e($membership['student_name']); ?>">
                                                                        <span class="form-error"></span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label>Membership Type</label>
                                                                        <input type="text" readonly placeholder="This will show in Front end" 
                                                                        class="form-control cForm"  value="<?php echo e($membership['membership_name']); ?>">
                                                                        <span class="form-error"></span>
                                                                    </div>
                                                                </div>
                                                               
                                                            </div>

                                                            <div class="row">
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label>Membership Plan</label>
                                                                            <input type="text" readonly  placeholder="This will show in Front end" 
                                                                        class="form-control cForm" value="<?php echo e($membership['membership_plan']); ?>">
                                                                            <span class="form-error"></span>
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label>Date Joined</label>
                                                                            <input type="text" readonly  placeholder="This will show in Front end" 
                                                                            class="form-control cForm"  value="<?php echo e($membership['date_joined']); ?>">
                                                                            <span class="form-error"></span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label>Is Expired</label>
                                                                            <input type="text" readonly placeholder="This will show in Front end" 
                                                                            class="form-control cForm"  value="<?php if($membership['is_expired']=='0'): ?> Active <?php else: ?> Expired <?php endif; ?>">
                                                                            <span class="form-error"></span>
                                                                        </div>
                                                                    </div>
                                                                   
                                                            </div>
                                                            <div class="row">
                                                                    <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                    <label>Session</label>
                                                                                    <input type="text" readonly  placeholder="This will show in Front end" 
                                                                                    class="form-control cForm"  value="<?php echo e($membership['session']); ?>">
                                                                                    <span class="form-error"></span>
                                                                                </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                    <label>User Address<address></address></label>
                                                                                    <input type="text" readonly  placeholder="This will show in Front end" 
                                                                                    class="form-control cForm"  value="<?php echo e($membership['address']); ?>">
                                                                                    <span class="form-error"></span>
                                                                                </div>
                                                                    </div>

                                                            </div>
                                                            <div class="row">
                                                                    <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                    <label>User Mobile<address></address></label>
                                                                                    <input type="text" readonly  placeholder="This will show in Front end" 
                                                                                    class="form-control cForm"  value="<?php echo e($membership['phone_no']); ?>">
                                                                                    <span class="form-error"></span>
                                                                                </div>
                                                                    </div>
                                                            </div>
                                                            <div class="clearfix">

                                                            </div>
                                                            <div class="row">
                                                                    
                                                                <div class="col-md-6">
                                                                        <table class="col-md-12" border="1">
                                                                            <tr>
                                                                            <td>Status</td>
                                                                            <td>Available for Order</td>
                                                                            <td>Result</td>
                                                                            </tr>
                                                                            <tr>
                                                                                    <td>Not Applicable</td>
                                                                                    <td>No</td>
                                                                                    <td>Not Applicable</td>
                                                                            </tr>
                                                                            <tr>
                                                                                    <td>Pending</td>
                                                                                    <td>No</td>
                                                                                    <td>Pending</td>
                                                                            </tr>
                                                                            <tr>
                                                                                    <td>Pending</td>
                                                                                    <td>Yes</td>
                                                                                    <td>Place Order</td>
                                                                            </tr>
                                                                            <tr>
                                                                                    <td>Ordered</td>
                                                                                    <td>Yes</td>
                                                                                    <td>Product Ordered</td>
                                                                            </tr>
                                                                            <tr>
                                                                                    <td>Delivered</td>
                                                                                    <td>Yes</td>
                                                                                    <td>Product Delivered</td>
                                                                            </tr>
                                                                        </table>
                                                                </div>
                                                            </div>
                                                        <div class="row">
                                                            
                                                            <div class="col-md-12">
                                                               
                                                                <table class="col-md-12">
                                                                       
                                                                        <?php $__currentLoopData = $membership['details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td>
                                                                                    <div class="input-group">
                                                                                        <label>Product</label>
                                                                                        <input type="text" readonly class="form-control cForm" 
                                                                                            style="margin: 0 10px;" value="<?php echo e($item['product_name']); ?>">
                                                                                    <input type="hidden" name="product_id[<?php echo e($item['product_id']); ?>]" value="<?php echo e($item['product_id']); ?>">
                                                                                    <span class="form-error"></span>
                                                                                    <input type="hidden" name="membership_product_id[<?php echo e($item['membership_product_id']); ?>]" value="<?php echo e($item['membership_product_id']); ?>"> 
                                                                                        
                                                                                    </div>
                                                                            </td>
                                                                            <td>
                                                                                    <div class="input-group">
                                                                                        <label>Status</label>
                                                                                        <select name="inputStatus[<?php echo e($item['membership_product_id']); ?>]" class="form-control cForm" style="margin: 0 10px;">
                                                                                                <option value="notapplicable" <?php if($item['status']=='notapplicable'): ?> selected <?php endif; ?>>Not Applicable</option>
                                                                                                <option value="pending" <?php if($item['status']=='pending'): ?> selected <?php endif; ?>>Pending</option>
                                                                                            <option value="delivered" <?php if($item['status']=='delivered'): ?> selected <?php endif; ?>>Delivered</option>
                                                                                            <option value="ordered" <?php if($item['status']=='ordered'): ?> selected <?php endif; ?>>Ordered</option>
                                                                                            
                                                                                            
                                                                                        </select>
                                                                                        <span class="form-error"></span>
                                                                                    </div>
                                                                            </td>
                                                                            <td>
                                                                                    <div class="input-group">
                                                                                        <label>Available for Order</label>
                                                                                        <select name="inputAvailableOrder[<?php echo e($item['membership_product_id']); ?>]" class="form-control cForm" 
                                                                                        style="margin: 0 10px;" <?php if($item['status']=='ordered'): ?> disabled <?php endif; ?>>
                                                                                              
                                                                                            <option value="yes" <?php if($item['is_orderable']=='yes'): ?> selected <?php endif; ?>>Yes</option>
                                                                                            <option value="no" <?php if($item['is_orderable']=='no'): ?> selected <?php endif; ?>>NO</option>
                                                                                            
                                                                                            
                                                                                        </select>
                                                                                        <span class="form-error"></span>
                                                                                    </div>
                                                                            </td>
                                                                        
                                                                        </tr>
                                                                       
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </table>
                                                                   
                                                            </div>
                                                         
                                                                
                                
                                                        </div>
                                                        <div class="row">
                                                            
                                                            <div class="col-md-6 col-xs-6">
                                                                <div class="text-right mrg-top-5">
                                                                    <button type="submit" class="btn btn-success" id="updateStudentMembershipSubmit">Save</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>