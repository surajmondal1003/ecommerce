 <?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-heading border bottom">
                <h4 class="card-title">Edit Prdouct</h4>
            </div>
            <div class="card-block">
                <div class="mrg-top-40">
                    <div class="row">
                        <div class="col-md-12 ml-auto mr-auto">
                            <form id="orderDetailForm">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="card">
                                            <div class="card-block">

                                                <div class="tab-info">
                                                    <ul class="nav nav-tabs" role="tablist">
                                                        <li class="nav-item">
                                                            <a href="#default-tab-1" class="nav-link active" role="tab" data-toggle="tab" aria-expanded="true">Order Details</a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="#default-tab-2" class="nav-link" role="tab" data-toggle="tab" aria-expanded="false">Shipping Details</a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="#default-tab-3" class="nav-link" role="tab" data-toggle="tab" aria-expanded="false">Products</a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="#default-tab-4" class="nav-link" role="tab" data-toggle="tab" aria-expanded="false">History</a>
                                                        </li>
                                                        
                                                       
                                                    </ul>
                                                    <div class="tab-content">
                                                        <div role="tabpanel" class="tab-pane fade in active show" id="default-tab-1" aria-expanded="true">
                                                          
                                                            <div class="pdd-horizon-15 pdd-vertical-20">
                                                                <div class="row">
                                                                        <table id="orderdetails" border="1" class="col-md-12">
                                                                                
                                                                            <tr>
                                                                                <td>Order No</td>
                                                                                <td><?php echo e($order['order_no']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Invoice No</td>
                                                                                <td><?php echo e($order['invoice_no']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Customer Name</td>
                                                                                <td><?php echo e($order['name']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Customer Email</td>
                                                                                <td><?php echo e($order['email']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Customer Mobile</td>
                                                                                <td><?php echo e($order['phone_no']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Customer Type</td>
                                                                                <td><?php echo e($order['type']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Membership ID</td>
                                                                                <td><?php echo e($order['student_unique_no']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Order Net Amount</td>
                                                                                <td><?php echo e($order['net_total']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Order Status</td>
                                                                                <td><?php echo e($order['status']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Date Created</td>
                                                                                <td><?php echo e($order['created_at']); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Date Modified</td>
                                                                                <td><?php echo e($order['updated_at']); ?></td>
                                                                            </tr>
                                                                           
                                                                        </table>
                                                                </div>

                                                            </div>
                                                        </div>
                                                        <div role="tabpanel" class="tab-pane fade" id="default-tab-2" aria-expanded="false">
                                                                <table id="shippingdetails" border="1" class="col-md-12">
                                                                                
                                                                        <tr>
                                                                            <td>Address</td>
                                                                            <td><?php echo e($order['address']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Landmark</td>
                                                                            <td><?php echo e($order['landmark']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>City</td>
                                                                            <td><?php echo e($order['city']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Pincode</td>
                                                                            <td><?php echo e($order['pincode']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Payment Mode</td>
                                                                            <td><?php echo e($order['paymentmode']); ?></td>
                                                                        </tr>
                                                                      
                                                                       
                                                                    </table>
                                                        </div>
                                                        <div role="tabpanel" class="tab-pane fade" id="default-tab-3" aria-expanded="false">
                                                                <table id="orderdetails" border="1" class="col-md-12">
                                                                    <tr>
                                                                            <td>Product Name</td>
                                                                            <td>Quantity</td>
                                                                            <td>Subtotal</td>
                                                                    </tr>
                                                                    <?php $__currentLoopData = $order['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
                                                                        <tr>
                                                                            
                                                                            <td><?php echo e($product_item['product_name']); ?></td>
                                                                            <td><?php echo e($product_item['qty']); ?></td>
                                                                            <td><?php echo e($product_item['subtotal']); ?></td>
                                                                        </tr>
                                                                       
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                       <tr>
                                                                           <td colspan="2" style="text-align:right;">Item Total</td>
                                                                           <td colspan="2" style="text-align:right;"><?php echo e($order['itemtotal']); ?></td>
                                                                       </tr>
                                                                       <tr>
                                                                           <td colspan="2" style="text-align:right;">Delivery Charges</td>
                                                                           <td colspan="2" style="text-align:right;"><?php echo e($order['delivery_charge']); ?></td>
                                                                       </tr>
                                                                       <tr>
                                                                            <td colspan="2" style="text-align:right;">Total</td>
                                                                            <td colspan="2" style="text-align:right;"><?php echo e($order['net_total']); ?></td>
                                                                        </tr>
                                                                    </table>
                                                        </div>
                                                        <div role="tabpanel" class="tab-pane fade" id="default-tab-4" aria-expanded="false">
                                                                <table id="orderdetails" border="1" class="col-md-12">
                                                                        <tr>
                                                                                <td>Date Added</td>
                                                                                <td>Status</td>
                                                                                
                                                                        </tr>
                                                                    <?php $__currentLoopData = $order['order_status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                                                       
                                                                        <tr>
                                                                            <td><?php echo e($statusItem->created_at); ?></td>
                                                                            <td><?php echo e($statusItem->status); ?></td>
                                                                        </tr>
                                                                       
                                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </table>

                                                                    <div class="row">
                                                                            <div class="col-md-6 col-xs-6">
                                                                                <div class="form-group">
                                                                                        <label>Order Status</label>
                                                                                        

                                                                                        <select name="inputOrderStatus"  class="form-control cForm">
                                                                                                <option value="cancelled">Canceled</option>
                                                                                                <option value="cancelledreversal">Canceled Reversal</option>
                                                                                                <option value="chargeback">Chargeback</option>
                                                                                                <option value="delivered">Delivered</option>
                                                                                                <option value="denied">Denied</option>
                                                                                                <option value="expired">Expired</option>
                                                                                                <option value="failed">Failed</option>
                                                                                                <option value="outofprint">Out of Print</option>
                                                                                                <option value="pending">Pending</option>
                                                                                                <option value="processed">Processed</option>
                                                                                                <option value="processing">Processing</option>
                                                                                                <option value="refunded">Refunded</option>
                                                                                                <option value="reversed">Reversed</option>
                                                                                                <option value="shipped" selected="selected">Shipped</option>
                                                                                                <option value="voided">Voided</option>
                                                                                        </select>

        
                                                                                  
                                                                                    <span class="form-error"></span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6 col-xs-6">
                                                                                <div class="form-group">
                                                                                    <label>Notify User</label>
                                                                                    <input type="checkbox" checked name="inputNotifyUser" value="yes">
                                                                                    <input type="hidden"  name="order_id" value="<?php echo e($order['order_id']); ?>">
                                                                                    <span class="form-error"></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                        </div>
                                                       

                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="generalerror">
                                        </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 col-xs-6">
                                                <div class="text-right mrg-top-5">
                                                
                                                    <button type="submit" class="btn btn-success" id="updateOrderSubmit">Save</button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </div>


                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>