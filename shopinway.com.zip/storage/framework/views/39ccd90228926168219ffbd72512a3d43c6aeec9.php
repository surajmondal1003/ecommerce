<?php $__env->startSection('content'); ?>


<div class="inner-page-hd-member-form">
        <div class="container">
          <?php if($is_member): ?>

          <h1 class="memh1 on cartCount text-red blink-soft">Sorry..You are already a member. You have joined <?php echo e($is_member->membership_name); ?> for <?php echo e($is_member->membership_plan); ?>.</h1>
          <div class="cntr-algn">
            <a href="<?php echo e(url('')); ?>" class="buybtn-to-continue on">Continue Shopping</a>
          </div>
          <?php else: ?>

          <h1 class="memh1">Membership form for <?php echo e($membership->membership_name); ?></h1>
          <div class="row">
          <div class="col-md-7 col-sm-7 col-xs-12">
          <div class="member-form sub">
            <div class="row">
              <form id="savememberform">


                  <div class="top-sec2">
                      <div class="step1" id="addressStep1">
                          <h2>Delivery Address</h2>
                            <div>
                              
                              <?php if(count($useraddress)<1): ?>
                              
                               <div class="row">
                                <div class="col-md-12">
                                    <h4>You have no addresses yet</h4>
                                    
                                </div>
                              </div> 
                              <?php else: ?>
                              <?php $__currentLoopData = $useraddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachaddress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
                              
                            <div class="md-radio md-radio-inline">
                              <input id="<?php echo e($eachaddress->user_address_id); ?>" type="radio" name="inputSaddress" value="<?php echo e($eachaddress->user_address_id); ?>"
                              <?php if($eachaddress->is_default=='1'): ?> checked <?php endif; ?> onclick="loadMembershipDeliverBtn(this.value)">
                              <label for="<?php echo e($eachaddress->user_address_id); ?>">
                              <div class="box-new " id="addressText_<?php echo e($eachaddress->user_address_id); ?>">
          
                                    <h3><?php echo e($user->name); ?><span>(<?php echo e($eachaddress->phone_no); ?>)</span></h3>
                                    <p><?php echo e($eachaddress->address); ?>,<?php echo e($eachaddress->landmark); ?>,
                                      <?php echo e($eachaddress->pincode); ?>,<?php echo e($eachaddress->city); ?>,<?php echo e($eachaddress->country); ?></p>
          
                              </div>
                                </label>
                              </div>
                              <div id="addressDeliverDiv_<?php echo e($eachaddress->user_address_id); ?>">
                                <?php if($eachaddress->is_default=='1'): ?>
                              <button type="button" class="buybtn deliver-btn" value="<?php echo e($eachaddress->user_address_id); ?>" onclick="checkMembershiporderPincode(this.value)">Deliver Here</button>
                                <?php endif; ?>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </div>
                        <button type="button" class="popup-address" data-toggle="modal" data-target="#myModal">Add new</button>
                        
                    </div>
                  </div>



                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                     <select class="form-control cForm" name="inputSdept" onchange="getSemester(this.value)">
                            <option value="0">Select Degree</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($cat->category_id); ?>"><?php echo e($cat->category_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 
                    <span class="help-block"></span>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group" id="streamDiv">
                        <select  name="inputStream" class="form-control cForm" onchange="changePlan(this.value)">
                        <option value="0">Select Stream</option>
                      
                        </select>
                        <span class="help-block"></span>
                  </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group" id="semesterDiv">
                        <select  name="inputPlan" class="form-control cForm" onchange="changePlan(this.value)">
                        <option value="0">Select Semesters</option>
                      
                        </select>
                        <span class="help-block"></span>
                  </div>
                </div>
               
                
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                  <input type="text" name="inputSname" readonly placeholder="Name" class="form-control cForm" value="<?php echo e($user->name); ?>">
                  <span class="help-block"></span>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <input type="Email" name="inputSemail" readonly placeholder="Email" class="form-control cForm" value="<?php echo e($user->email); ?>">
                    <span class="help-block"></span>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <input type="text" name="inputSphone" readonly placeholder="Phone" class="form-control cForm" value="<?php echo e($user->mobile); ?>">
                    <span class="help-block"></span>
                  </div>
                </div>
                
               
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <input type="text" name="inputScollege" placeholder="College" class="form-control cForm">
                    <span class="help-block"></span>
                  </div>
                </div>
                
                
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <input type="text" name="inputSrefferal" placeholder="Referral Id" class="form-control cForm">
                    <span class="help-block"></span>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group">
                  <div class="final-payable-ammount" >
                    <h2 class="cartCount text-red blink-soft" id="planPrice"></h2>
                  </div>
                </div>
                </div>
            
            
                  
                <div id="placeorderdiv" class="col-md-12 col-sm-12 col-xs-12">
                    <?php if(count($useraddress)<1): ?>
                          
                    <p class="eror">You have no address.Please Add address</p>
                    

                    <?php endif; ?>
                    <p class="eror" id="undeliverableorder"></p>
                    
                  
                </div>
               

               
              </form>

              <div class="modal fade" id="myModal" role="dialog">
                  <div class="container-fluid">
                  <div class="modal-dialog">
                  
                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">New Address</h4>
                      </div>
                      <div class="modal-body">
                        <form id="addressmemberdialogform">
                        <div class="form-group">
                          <input type="text" name="inputAddress" placeholder="New Address" class="form-control" >
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                          <input type="text" name="inputLandmark" placeholder="Landmark" class="form-control" >
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                          <input type="text" name="inputCity" placeholder="City" class="form-control" >
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                          <input type="text" name="inputPincode" placeholder="Pincode" class="form-control" >
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                          <input type="text" readonly name="inputCountry" value="INDIA" class="form-control" >
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                          <input type="submit" value="submit" id="addressmemberdialogBtn" class="sub-btn">
                        </div>
                        </form>
                      </div>
                      <!-- <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div> -->
                    </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>
          </div>

          <div class="col-md-5 col-sm-5 col-xs-12">
            <div class="plan-desc" class="natural">
                    <div class="card-inr">
                            <h2 class="card-heading"><?php echo e($membership->membership_name); ?></h2>
                            <div class="prime-desc">
                              <p> <?php echo e($membership->description); ?> </p>
                            </div>
                            <div class="prime-price">
                              <table>
                                <tr>
                                  <th>TENURE </th>
                                 
                                  <th> Prime Price</th>
                                </tr>
                                
                                <?php $__currentLoopData = $membershipdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($item->membership_plan); ?></td>
                                 
                                <td class="bg">Rs <?php echo e($item->membership_price); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
                              </table>
                            </div>

                          </div>
            </div>   
          </div>
        </div>
        <?php endif; ?>
        </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>