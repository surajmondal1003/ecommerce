@extends('layouts.admin')
@section('content')
<div class="row">
                            <div class="col-md-12">
                                <form id="orderListForm" method="POST" target="_blank" action="/admin/print-shipping-details">
                                    @csrf
                                <div class="card">
                                    <div class="card-heading border bottom">
                                        <h4 class="card-title">List of Orders </h4>
                                        <div class="col text-right"><button type="submit" class="btn btn-success" id="printShippingInvoice">Print Shipping Invoice</button></div>
                                        <div class="col text-right"><a class="btn btn-success" href="{{ url('admin/add-product') }}">Add New Order</a></div>
                                    </div>
                                    <div class="card-block">
                                    <div class="table-overflow">
                                            <table id="tableorderlist" class="table table-lg table-hover">
                                                <thead>
                                                        
                                                        <th>Check Order</th>
                                                        <th>Order No</th>
                                                        <th>Customer Type</th>
                                                        <th>Customer</th>
                                                        <th>Membership Number</th>
                                                        <th>Total</th>
                                                        <th>Date Added</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                 
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                    </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
@endsection